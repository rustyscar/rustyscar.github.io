r"""
setup_config.py — 自動設定 Claude Desktop 的 MCP Server 連線

由 install.bat 呼叫，不需手動執行。
用法: python setup_config.py <server.py 完整路徑> [python 執行檔]

會處理「兩種安裝情境」：
  1. 官網下載版 Claude Desktop → %APPDATA%\Claude\
  2. Microsoft Store 版（沙盒）→ %LOCALAPPDATA%\Packages\Claude*\LocalCache\Roaming\Claude\
兩個位置都會寫入，確保不論哪種安裝方式都能連上。

command 一律寫「完整 Python 路徑」，避免 Claude Desktop 啟動時 PATH 找不到 python。
"""

import json
import os
import glob
import shutil
import sys
from pathlib import Path


def resolve_python(arg_pycmd):
    """決定 MCP 設定要寫的 python 執行檔。
    優先用傳入的完整路徑；若傳入 'python'/'py' 或未傳，
    則改用目前直譯器的 sys.executable（完整路徑，最可靠）。"""
    if arg_pycmd and (arg_pycmd.lower().endswith(".exe") or ("\\" in arg_pycmd)):
        return str(Path(arg_pycmd))
    # 'python' / 'py' / 空 → 用實際完整路徑
    return sys.executable


def find_config_locations():
    """回傳所有可能的 Claude Desktop config 檔路徑（涵蓋兩種安裝情境）。"""
    locations = []

    # 1) Microsoft Store 沙盒版
    local = os.environ.get("LOCALAPPDATA", "")
    if local:
        pattern = os.path.join(local, "Packages", "Claude*", "LocalCache", "Roaming", "Claude")
        for sp in glob.glob(pattern):
            locations.append(Path(sp) / "claude_desktop_config.json")

    # 2) 官網安裝版（標準路徑）
    appdata = os.environ.get("APPDATA", "")
    if appdata:
        locations.append(Path(appdata) / "Claude" / "claude_desktop_config.json")

    return locations


def write_config(cfg_path, server_path, pycmd):
    """安全寫入單一 config（保留既有設定、備份、不覆蓋其他 server）。"""
    cfg_path.parent.mkdir(parents=True, exist_ok=True)

    config = {}
    if cfg_path.exists():
        try:
            config = json.loads(cfg_path.read_text(encoding="utf-8"))
            backup = cfg_path.with_suffix(".json.bak")
            shutil.copy2(cfg_path, backup)
        except json.JSONDecodeError:
            config = {}

    if "mcpServers" not in config:
        config["mcpServers"] = {}

    config["mcpServers"]["geotech"] = {
        "command": pycmd,
        "args": [server_path],
    }

    cfg_path.write_text(
        json.dumps(config, indent=2, ensure_ascii=False), encoding="utf-8"
    )


def locate_existing_server():
    """讀取 Claude Desktop 設定檔，回傳目前 geotech server 的實際路徑。
    供 install.bat 升級時定位『Claude 真正載入的那個 server』，
    避免更新到錯誤位置。找到就 print 路徑並 exit 0；找不到 exit 1。"""
    for cfg in find_config_locations():
        if not cfg.exists():
            continue
        try:
            data = json.loads(cfg.read_text(encoding="utf-8"))
            srv = data.get("mcpServers", {}).get("geotech", {})
            args = srv.get("args", [])
            if args:
                print(args[0])
                sys.exit(0)
        except Exception:
            continue
    sys.exit(1)


def main():
    if len(sys.argv) >= 2 and sys.argv[1] == "--locate":
        locate_existing_server()
        return
    if len(sys.argv) < 2:
        print("用法: python setup_config.py <server.py 完整路徑> [python 執行檔]")
        sys.exit(1)

    server_path = sys.argv[1]
    pycmd = resolve_python(sys.argv[2] if len(sys.argv) >= 3 else None)

    locations = find_config_locations()
    if not locations:
        print("    [!] 找不到任何 Claude Desktop config 位置")
        sys.exit(1)

    written = []
    for cfg in locations:
        try:
            write_config(cfg, server_path, pycmd)
            written.append(str(cfg))
        except Exception as e:
            print(f"    (skip {cfg}: {e})")

    print(f"    Python (command): {pycmd}")
    print(f"    寫入了 {len(written)} 個 config 位置：")
    for w in written:
        print(f"      {w}")


if __name__ == "__main__":
    main()
