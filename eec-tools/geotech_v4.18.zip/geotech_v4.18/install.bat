@echo off
REM Geotech Analysis System - Installer / Updater v4.18
REM Pure ASCII + CRLF. No parenthesized blocks containing quoted commands.
title Geotech Analysis System - Setup v4.18
setlocal enabledelayedexpansion

set "PYVERSION=3.12.7"
set "PYURL=https://www.python.org/ftp/python/%PYVERSION%/python-%PYVERSION%-amd64.exe"
set "INSTALL_DIR=%USERPROFILE%\geotech_mcp"
set "PYCMD="

echo.
echo ============================================
echo   Geotech Analysis System - Setup
echo   Version v4.18
echo ============================================
echo.

if exist "%INSTALL_DIR%\geotech_mcp_server.py" goto :UPGRADE
REM Also detect installs in a non-default location via Claude's own config.
call :FIND_PY
if not defined PYCMD goto :NO_EXISTING
for /f "usebackq delims=" %%P in (`"%PYCMD%" "%~dp0setup_config.py" --locate 2^>nul`) do set "FOUND_SERVER=%%P"
if defined FOUND_SERVER goto :UPGRADE_LOCATED
:NO_EXISTING
echo No existing install found. Running FULL install.
echo.
goto :FULL


REM ==================================================
REM  UPGRADE (server located via Claude config)
REM ==================================================
:UPGRADE_LOCATED
echo Existing install detected from Claude config:
echo   %FOUND_SERVER%
echo Running in UPGRADE mode (server file only).
echo.
call :FIND_PY
for %%I in ("%FOUND_SERVER%") do set "INSTALL_DIR=%%~dpI"
if "%INSTALL_DIR:~-1%"=="\" set "INSTALL_DIR=%INSTALL_DIR:~0,-1%"
goto :DO_UPGRADE


REM ==================================================
REM  UPGRADE MODE
REM ==================================================
:UPGRADE
echo Existing install found at:
echo   %INSTALL_DIR%
echo Running in UPGRADE mode (server file only).
echo.
call :FIND_PY
set "FOUND_SERVER=%INSTALL_DIR%\geotech_mcp_server.py"

:DO_UPGRADE
echo [1/3] Backing up current server...
set "STAMP=%DATE:/=-%_%TIME::=-%"
set "STAMP=%STAMP: =0%"
copy /y "%FOUND_SERVER%" "%FOUND_SERVER%.backup_%STAMP%" >nul
if errorlevel 1 goto :BK_FAIL
echo     [OK] Backed up.

echo [2/3] Installing new server...
copy /y "%~dp0geotech_mcp_server.py" "%FOUND_SERVER%" >nul
if errorlevel 1 goto :COPY_FAIL
call :ENSURE_PILLOW
echo     [OK] Server updated.

echo [3/3] Validating...
if not defined PYCMD goto :UP_DONE
"%PYCMD%" -c "import ast,io; ast.parse(io.open(r'%FOUND_SERVER%',encoding='utf-8').read())" 2>nul
if errorlevel 1 goto :SYNTAX_FAIL
echo     [OK] Syntax valid.
goto :UP_DONE

:SYNTAX_FAIL
echo     [X] Syntax check failed. Restoring backup...
copy /y "%FOUND_SERVER%.backup_%STAMP%" "%FOUND_SERVER%" >nul
echo     [OK] Restored previous version.
goto :END

:UP_DONE
echo.
echo ============================================
echo            UPGRADE COMPLETE  v4.18
echo ============================================
echo.
echo   Final step: FULLY close and reopen Claude
echo   Desktop (also quit the system-tray icon).
echo.
goto :END

:BK_FAIL
echo     [X] Backup failed. Aborting.
goto :END
:COPY_FAIL
echo     [X] Copy failed.
goto :END


REM ==================================================
REM  FULL INSTALL
REM ==================================================
:FULL
echo [1/5] Checking Python...
call :FIND_PY
if defined PYCMD goto :PYDONE

echo     [!] Python not found. Installing Python %PYVERSION%...
if exist "%~dp0python-installer.exe" goto :USE_LOCAL_PY
echo     Downloading Python from python.org (~25MB)...
powershell -NoProfile -Command "[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12; try { Invoke-WebRequest -Uri '%PYURL%' -OutFile '%TEMP%\python-installer.exe' -UseBasicParsing } catch { exit 1 }"
if errorlevel 1 goto :DL_FAIL
set "INSTALLER=%TEMP%\python-installer.exe"
goto :DOINSTALL

:USE_LOCAL_PY
echo     Using bundled installer.
set "INSTALLER=%~dp0python-installer.exe"

:DOINSTALL
echo     Installing Python (silent, user scope)...
start /wait "" "%INSTALLER%" /quiet InstallAllUsers=0 PrependPath=1 Include_launcher=1 Include_test=0
call :FIND_PY
if not defined PYCMD goto :PY_NEEDS_RESTART

:PYDONE
echo     [OK] Python: %PYCMD%
echo.
echo [2/5] Installing Python packages (fastmcp, playwright, Pillow)...
"%PYCMD%" -m pip install --upgrade pip >nul 2>&1
"%PYCMD%" -m pip install fastmcp playwright Pillow
if errorlevel 1 goto :PKG_FAIL
echo     [OK] Packages installed.

echo.
echo [3/5] Installing Chromium engine (~150MB)...
"%PYCMD%" -m playwright install chromium
echo     [OK] Chromium step done.

echo.
echo [4/5] Installing MCP server files...
if not exist "%INSTALL_DIR%" mkdir "%INSTALL_DIR%"
copy /y "%~dp0geotech_mcp_server.py" "%INSTALL_DIR%\geotech_mcp_server.py" >nul
echo     [OK] Server installed to %INSTALL_DIR%

echo.
echo [5/5] Configuring Claude Desktop...
"%PYCMD%" "%~dp0setup_config.py" "%INSTALL_DIR%\geotech_mcp_server.py" "%PYCMD%"
echo     [OK] Configuration done.

echo.
echo ============================================
echo            INSTALL COMPLETE  v4.18
echo ============================================
echo.
echo   Final step: FULLY close and reopen Claude
echo   Desktop (also quit the system-tray icon).
echo   Then open the usage guide HTML to start.
echo.
goto :END

:DL_FAIL
echo     [X] Download failed. Check network, or use offline mode.
goto :END
:PKG_FAIL
echo     [X] Package install failed. Check network and re-run.
goto :END
:PY_NEEDS_RESTART
echo     [!] Python installed but not detected. Please RESTART the
echo         computer and run install.bat again.
goto :END


REM ==================================================
REM  Helper: ensure Pillow (no parenthesized quoted cmds)
REM ==================================================
:ENSURE_PILLOW
if not defined PYCMD goto :eof
"%PYCMD%" -c "import PIL" >nul 2>&1
if not errorlevel 1 goto :eof
echo     Installing Pillow...
"%PYCMD%" -m pip install Pillow >nul 2>&1
goto :eof

REM ==================================================
REM  Helper: locate Python -> PYCMD
REM ==================================================
:FIND_PY
set "PYCMD="
python --version >nul 2>&1 && set "PYCMD=python"
if defined PYCMD goto :eof
py --version >nul 2>&1 && set "PYCMD=py"
if defined PYCMD goto :eof
if exist "%LOCALAPPDATA%\Programs\Python\Python314\python.exe" set "PYCMD=%LOCALAPPDATA%\Programs\Python\Python314\python.exe"
if defined PYCMD goto :eof
if exist "%LOCALAPPDATA%\Programs\Python\Python313\python.exe" set "PYCMD=%LOCALAPPDATA%\Programs\Python\Python313\python.exe"
if defined PYCMD goto :eof
if exist "%LOCALAPPDATA%\Programs\Python\Python312\python.exe" set "PYCMD=%LOCALAPPDATA%\Programs\Python\Python312\python.exe"
if defined PYCMD goto :eof
if exist "%LOCALAPPDATA%\Programs\Python\Python311\python.exe" set "PYCMD=%LOCALAPPDATA%\Programs\Python\Python311\python.exe"
goto :eof

:END
echo.
echo --- Press any key to close this window ---
pause >nul
