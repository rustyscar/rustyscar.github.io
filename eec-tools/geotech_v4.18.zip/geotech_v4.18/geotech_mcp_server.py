# geotech_mcp_server.py v4.18 (mono chart compression default, 8-hole one-shot)
# Breakthrough: Chart endpoint requires requests from WebWorker context.
# Browser doesn't add Origin/Sec-Fetch-* for Worker-originated fetches,
# and that's what the server's WAF filters on. Instead of faking headers,
# we spawn the site's actual Worker and postMessage into it.
#
# Changes from v4.12:
# - Auto-batching for inline mode: 8 boreholes × multiple pages of base64
#   PNG can exceed the 1 MB per-tool-result limit. The tool now fetches all
#   charts ONCE, caches them in-process, and returns results in size-bounded
#   batches. New `batch` parameter (default 1) selects which batch; the
#   response carries a `batch_plan` telling the caller whether more batches
#   remain and what to pass next. Charts are NOT re-fetched on batch>=2
#   (served from cache), so the expensive scrape happens only once.
#   No disk intermediate (unlike 'save'); images stay base64 in-memory.
#   Packing uses each hole's REAL serialized byte size (not an estimate),
#   so it stays correct across projects whose page images differ in size.
#   Hard-limit guard: a pathologically large single hole that still exceeds
#   1 MB on its own is degraded (images dropped, note to use 'save' for it)
#   so a batch can never hard-fail.
#
# Changes from v4.10:
# - Added `chart_mode` parameter to get_all_charts_for_analysis and
#   get_borehole_full_data. Values: 'inline' (default, base64 in response),
#   'save' (writes PNG files to ./geotech_output/<addr>_<date>/charts/
#    and returns paths), 'metadata' (page count only, no image data).
#   Motivation: 8 boreholes × multiple pages of base64 PNG can exceed
#   the 1 MB per-tool-result limit; 'save' mode sidesteps that by
#   writing files and returning lightweight paths.
# - Output directory naming mirrors the file-naming spec from
#   input_format.md: <地址>_<YYYYMMDD>/ as the project root, with
#   charts/ as a subfolder for per-page PNG files.
#
# Changes from v4.9:
# - DROPPED imageExist as a selection/skip criterion. Empirical observation
#   (HAR inspection + live test on Yongkang St case): the DrCoordsJson
#   imageExist flag is unreliable / stale — every borehole in the DB seems
#   to return "N", yet GeoReport Mode=Chart actually returns valid PNGs
#   for many of them. Selection is now: nearest > deepest > newest, and
#   we always attempt the chart fetch. The flag is kept in the response
#   (renamed 圖牆有無_資料庫標註) with a note that it's advisory only.
# - Added Mode=Test and Mode=BaseData fetch paths, reusing the same
#   WebWorker transport as Chart. (HAR analysis revealed these modes.)
# - Added HTML parser for Mode=Test response → structured JSON
#   (試驗編號, 深度, USCS, 含水量, LL, PI, 比重, 細料含量, ...).
# - New tool: get_borehole_full_data — one borehole, all three modes.
# - get_all_charts_for_analysis now attaches 基本資料 by default and
#   試驗資料 when include_test=True (default False, keeps it fast).
# - get_all_charts_for_analysis no longer skips boreholes on imageExist=N.
#
# Changes from v4.8 (retained):
# - Chart fetch uses `new Worker('/imoeagis/js/WebWorker/GetGeoReport.js')`
#   + postMessage; no more page.evaluate fetch, no route interception,
#   no DrillImageJson precall, no anti-headless scripts needed.
# - get_all_charts_for_analysis reuses a single browser/page across all
#   boreholes (was reopening per borehole).

import base64
import io
import json
import math
import re
from datetime import datetime
from pathlib import Path
from fastmcp import FastMCP

# Pillow 用於柱狀圖壓縮(彩色 256 色量化)。若未安裝則自動停用壓縮、
# 不影響其他功能(圖照樣回傳，只是不壓)。
try:
    from PIL import Image
    _PIL_OK = True
except ImportError:
    _PIL_OK = False

mcp = FastMCP("geotech")


# ===== 柱狀圖壓縮 (v4.18) =====
# 柱狀圖是線稿圖(白底黑字、少量土層色塊)。實測逐張比較：
#   原圖 ~60KB/頁  →  彩色256色 ~29KB  →  單色1-bit ~10KB
# 對「文字+N值判讀、花紋只需看出分類、且會再經 AI 後處理」的用途，
# 單色 1-bit 已足夠：土層文字/高程/N值/分段打擊數全清晰，唯一損失是
# 水位欄的『日期小字』會糊掉(高度數值在頁首仍可讀，日期不影響判讀)。
# 預設用單色，單頁僅 ~10KB → 8 孔多頁也遠低於 1MB，一次即可回完。
# mode='color256' 可切回彩色 256 色(容錯較高，遇掃描差的老圖時救援用)。
def _compress_page_data_url(data_url, mode="mono"):
    """量化 'data:image/png;base64,...' 的 PNG 以縮小 base64。
    mode='mono'     → 單色 1-bit(最小，預設)
    mode='color256' → 彩色 256 色(較大但容錯高)
    mode='none'     → 不壓
    失敗(無 Pillow、解碼錯誤等)時原樣回傳，確保永不因壓縮而掉圖。"""
    if mode == "none" or not _PIL_OK:
        return data_url
    try:
        prefix = "base64,"
        idx = data_url.find(prefix)
        if idx == -1:
            return data_url
        b64 = data_url[idx + len(prefix):]
        raw = base64.b64decode(b64)
        im = Image.open(io.BytesIO(raw))
        if mode == "mono":
            # 先灰階再二值化；dither=NONE 保線稿銳利、不抖點
            q = im.convert("L").convert("1", dither=Image.NONE)
        else:  # color256
            q = im.convert("RGB").quantize(colors=256, method=Image.FASTOCTREE)
        buf = io.BytesIO()
        q.save(buf, format="PNG", optimize=True)
        new_b64 = base64.b64encode(buf.getvalue()).decode("ascii")
        if len(new_b64) < len(b64):
            return "data:image/png;base64," + new_b64
        return data_url
    except Exception:
        return data_url


# ===== 分批 inline 快取 (v4.13) =====
# 問題：8 孔 × 多頁 base64 PNG 一次 inline 回傳會超過 1 MB tool-result 上限。
# 解法：抓圖「只做一次」存進此行程內快取，再用 batch 參數分多次切回，
#       每批控制在 _BATCH_BYTE_BUDGET 以內。避免重抓(最貴的步驟)、不落磁碟。
#
# 結構: key = (address, radius_m, include_test)
#       value = {
#           "summary_head": {...},          # 不含圖的摘要欄位(地址、孔數統計...)
#           "entries": [per-borehole dict], # 每孔完整資料(含 base64 圖)
#           "batches": [[idx,...], ...],    # 裝箱結果：每批包含哪幾個 entry 的索引
#           "created": epoch_seconds,
#       }
# 快取為行程內記憶體；server 重啟即清空。設 TTL 避免長存吃記憶體。
_CHART_CACHE = {}
_CACHE_TTL_SEC = 1800          # 30 分鐘後該筆快取視為過期
_BATCH_BYTE_BUDGET = 700_000   # 每批累計上限。v4.17 起柱狀圖量化成 256 色，
                               # 單頁 base64 從 ~130KB 降到 ~35KB，多數場址一次
                               # 即可回完。budget 700KB 下，框架包裝後仍 <1MB；
                               # 極端多孔才分批。降級保險(SAFE_LIMIT)仍在。


def _cache_key(address, radius_m, include_test):
    return f"{address}|{radius_m}|{bool(include_test)}"


def _cache_get(key):
    """取回未過期的快取；過期則刪除並回 None。"""
    import time
    item = _CHART_CACHE.get(key)
    if not item:
        return None
    if time.time() - item["created"] > _CACHE_TTL_SEC:
        _CHART_CACHE.pop(key, None)
        return None
    return item


def _entry_byte_size(entry):
    """估算單一孔 entry 在最終回應中佔的位元組數。
    最終回應用 json.dumps(indent=2) 且外層還有框架 wrap_result 包裝，
    實測膨脹約 2 倍。這裡用 indent=2 量、再乘安全係數，讓裝箱估算貼近
    真實輸出大小，避免低估導致單批超量。"""
    base = len(json.dumps(entry, ensure_ascii=False, indent=2).encode("utf-8"))
    return int(base * 1.15)  # 額外緩衝，涵蓋框架包裝/轉義


def _pack_batches(entries):
    """裝箱：把每孔 entry 依序列化大小分組，每組 ≤ _BATCH_BYTE_BUDGET。
    回傳 list of list[int]，每個子 list 是該批包含的 entry 索引。
    單孔若自身就超過 budget(極少見：單孔多頁特大圖)，獨立成一批，
    讓它至少能單獨回傳(由上層決定是否再降級)。"""
    batches = []
    cur, cur_bytes = [], 0
    for i, e in enumerate(entries):
        sz = _entry_byte_size(e)
        if cur and cur_bytes + sz > _BATCH_BYTE_BUDGET:
            batches.append(cur)
            cur, cur_bytes = [], 0
        cur.append(i)
        cur_bytes += sz
    if cur:
        batches.append(cur)
    return batches


def _emit_batch(cached, batch):
    """從快取切出第 `batch` 批，組成回應 JSON 字串。
    batch 從 1 起算；超出範圍時回明確錯誤(附正確範圍)。"""
    batches = cached["batches"]
    total = len(batches)

    if total == 0:
        # 沒有任何孔有圖
        out = dict(cached["summary_head"])
        out["boreholes"] = []
        out["batch_plan"] = {
            "current": 1, "total_batches": 0, "has_more": False,
            "this_batch_holes": [], "next_call": None,
        }
        return json.dumps(out, ensure_ascii=False, indent=2)

    if batch < 1 or batch > total:
        return json.dumps({
            "error": "batch out of range",
            "requested_batch": batch,
            "valid_range": f"1..{total}",
            "hint": f"此查詢共 {total} 批，請以 batch=1..{total} 取用。",
        }, ensure_ascii=False, indent=2)

    idxs = batches[batch - 1]
    entries = [cached["entries"][i] for i in idxs]
    hole_nos = [e.get("\u5b54\u865f", "?") for e in entries]

    out = dict(cached["summary_head"])
    out["boreholes"] = entries
    out["batch_plan"] = {
        "current": batch,
        "total_batches": total,
        "has_more": batch < total,
        "this_batch_holes": hole_nos,
        "next_call": (f"batch={batch + 1}" if batch < total else None),
    }
    payload = json.dumps(out, ensure_ascii=False, indent=2)
    payload_bytes = len(payload.encode("utf-8"))

    # 硬上限保險：emit 算的 payload_bytes 是 indent=2 大小，框架 wrap_result
    # 包裝後實際再大 ~15%(實測 log)。門檻取 780KB，確保框架包裝後仍 <1MB。
    SAFE_LIMIT = 780_000
    if payload_bytes > SAFE_LIMIT:
        degraded = []
        for e in entries:
            d = {k: v for k, v in e.items() if k != "\u67f1\u72c0\u5716"}
            if "\u67f1\u72c0\u5716" in e:
                d["\u67f1\u72c0\u5716_\u5df2\u7701\u7565"] = (
                    f"此孔圖量過大，單批序列化 {payload_bytes} bytes 超過安全門檻；"
                    f"請改用 chart_mode='save' 單獨取此孔({e.get('孔號','?')})柱狀圖。"
                )
            degraded.append(d)
        out["boreholes"] = degraded
        out["batch_plan"]["degraded"] = True
        payload = json.dumps(out, ensure_ascii=False, indent=2)

    return payload


# ===== Coordinate Utilities =====

def to_epsg3857(lon, lat):
    x = lon * 20037508.34 / 180
    y = math.log(math.tan((90 + lat) * math.pi / 360)) / (math.pi / 180) * 20037508.34 / 180
    return x, y

def from_epsg3857(x, y):
    lon = x * 180 / 20037508.34
    lat = (math.atan(math.exp(y * math.pi / 20037508.34)) * 360 / math.pi) - 90
    return lat, lon

def haversine(lat1, lon1, lat2, lon2):
    R = 6371000
    dLat = math.radians(lat2 - lat1)
    dLon = math.radians(lon2 - lon1)
    a = math.sin(dLat/2)**2 + math.cos(math.radians(lat1))*math.cos(math.radians(lat2))*math.sin(dLon/2)**2
    return R * 2 * math.atan2(math.sqrt(a), math.sqrt(1-a))

def make_bbox_wkt(lat, lon, radius_m):
    d_lat = radius_m / 111320
    d_lon = radius_m / (111320 * math.cos(math.radians(lat)))
    sw = to_epsg3857(lon - d_lon, lat - d_lat)
    ne = to_epsg3857(lon + d_lon, lat + d_lat)
    return f"POLYGON(({sw[0]} {sw[1]},{sw[0]} {ne[1]},{ne[0]} {ne[1]},{ne[0]} {sw[1]},{sw[0]} {sw[1]}))"

def get_bearing(lat1, lon1, lat2, lon2):
    d_lon = math.radians(lon2 - lon1)
    y = math.sin(d_lon) * math.cos(math.radians(lat2))
    x = math.cos(math.radians(lat1))*math.sin(math.radians(lat2)) - \
        math.sin(math.radians(lat1))*math.cos(math.radians(lat2))*math.cos(d_lon)
    return (math.degrees(math.atan2(y, x)) + 360) % 360

def bearing_to_sector(bearing):
    sectors = ['N','NE','E','SE','S','SW','W','NW']
    return sectors[round(bearing / 45) % 8]


# ===== Shared browser launcher =====

async def _new_page(p):
    browser = await p.chromium.launch(
        headless=True,
        args=['--disable-dev-shm-usage', '--no-sandbox']
    )
    context = await browser.new_context(
        user_agent=(
            'Mozilla/5.0 (Windows NT 10.0; Win64; x64) '
            'AppleWebKit/537.36 (KHTML, like Gecko) '
            'Chrome/147.0.0.0 Safari/537.36'
        ),
        ignore_https_errors=True,  # govt cert sometimes missing Subject Key Identifier
    )
    page = await context.new_page()
    return browser, page


async def _goto_map(page):
    """Navigate to the geotech map page; needed before WebWorker can be spawned
    from same-origin. Idempotent — safe to call again on an already-loaded page."""
    if 'geotech.gsmma.gov.tw' not in page.url:
        await page.goto(
            "https://geotech.gsmma.gov.tw/imoeagis/Home/Map",
            wait_until="domcontentloaded", timeout=20000
        )
        await page.wait_for_timeout(1500)


# ===== Geocoding =====

async def geocode_address(address):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser, page = await _new_page(p)
        try:
            await page.goto(
                f"https://www.google.com/maps/search/{address}",
                wait_until="domcontentloaded", timeout=15000
            )
            for _ in range(20):
                await page.wait_for_timeout(500)
                url = page.url
                match = re.search(r'@(-?[\d.]+),(-?[\d.]+)', url)
                if match:
                    return {"lat": float(match.group(1)), "lon": float(match.group(2)), "url": url}
            return {"error": f"geocoding failed: {page.url}"}
        finally:
            await browser.close()


# ===== Borehole Query (on an existing page) =====

async def _query_boreholes_on_page(page, lat, lon, radius_m=200, max_holes=0):
    """Run the borehole query on a page that is already on the geotech map.

    max_holes: 0 = 不限制(原本 8 方向各 1 孔行為)。
               >0 = 先選 8 方向代表孔，再取其中最近的 max_holes 孔，
               兼顧『限制數量』與『方向分散』，避免高密度場址超量/卡死。
    """
    await _goto_map(page)

    boreholes = []
    actual_radius = radius_m
    for r in [radius_m, 500, 1000]:
        wkt = make_bbox_wkt(lat, lon, r)
        boreholes = await page.evaluate("""
            async (wkt) => {
                const res = await fetch('/imoeagis/api/DrCoordsJson', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json; charset=utf-8'},
                    body: JSON.stringify({aWKT: [wkt], Limit: 0, BeginDepth: '', EndDepth: ''})
                });
                return await res.json();
            }
        """, wkt)
        actual_radius = r
        if boreholes:
            break

    if not boreholes:
        return {"error": "no boreholes found", "radius": actual_radius}

    enriched = []
    for bh in boreholes:
        base_data = await page.evaluate("""
            async (args) => {
                const res = await fetch('/imoeagis/api/GeoReport', {
                    method: 'POST',
                    headers: {'Content-Type': 'application/json; charset=utf-8'},
                    body: JSON.stringify({Mode: 'BaseData', ProjectKeyId: args.pk, KeyId: args.kid})
                });
                const data = await res.json();
                const parser = new DOMParser();
                const doc = parser.parseFromString(data[0] || '', 'text/html');
                const info = {};
                doc.querySelectorAll('tr').forEach(r => {
                    const th = r.querySelector('th');
                    const td = r.querySelector('td');
                    if (th && td) info[th.textContent.trim()] = td.textContent.trim();
                });
                return info;
            }
        """, {"pk": bh["projectKeyid"], "kid": bh["keyid"]})

        pt_match = re.search(r'POINT\s*\(\s*([\d.]+)\s+([\d.]+)\)', bh["wkt"])
        dist, bearing = 99999, 0
        if pt_match:
            bh_lat, bh_lon = from_epsg3857(float(pt_match.group(1)), float(pt_match.group(2)))
            dist = haversine(lat, lon, bh_lat, bh_lon)
            bearing = get_bearing(lat, lon, bh_lat, bh_lon)

        depth = float(base_data.get('\u947d\u5b54\u7e3d\u7e3d\u6df1\u5ea6', '0') or '0')
        date_str = base_data.get('\u947d\u63a2\u5b8c\u6210\u65e5\u671f', '0') or '0'
        date_num = int(re.sub(r'\D', '', date_str) or '0')

        enriched.append({
            "keyid": bh["keyid"], "projectKeyid": bh["projectKeyid"],
            "holePointNo": bh["holePointNo"], "projName": bh["projName"],
            "imageExist": bh.get("imageExist", ""),
            "dist": round(dist), "bearing": round(bearing),
            "sector": bearing_to_sector(bearing),
            "depth": depth, "dateStr": date_str, "dateNum": date_num,
            "info": base_data
        })

    sectors = ['N','NE','E','SE','S','SW','W','NW']
    selected = []
    for sec in sectors:
        in_sec = [b for b in enriched if b["sector"] == sec]
        if not in_sec:
            continue
        # v4.10: imageExist is no longer a selection criterion (flag is unreliable).
        # Order: nearest > deepest > newest.
        in_sec.sort(key=lambda b: (b["dist"], -b["depth"], -b["dateNum"]))
        selected.append(in_sec[0])

    # 限制孔數：先有 8 方向代表孔，再取最近的 max_holes 孔。
    # 高密度場址(如捷運沿線)8 孔多頁會超量/抓圖卡死，限制孔數是治本。
    capped = False
    if max_holes and len(selected) > max_holes:
        selected.sort(key=lambda b: b["dist"])
        selected = selected[:max_holes]
        capped = True

    covered = [s["sector"] for s in selected]
    missing = [s for s in sectors if s not in covered]

    result = {
        "address_lat": lat, "address_lon": lon,
        "radius_m": actual_radius,
        "total_found": len(boreholes),
        "selected_count": len(selected),
        "max_holes": max_holes,
        "capped_to_nearest": capped,
        "covered_sectors": covered,
        "missing_sectors": missing,
        "_note_imageExist": "圖牆有無_資料庫標註 欄位僅供參考,資料庫該旗標不可靠,實際抓圖不依賴此旗標",
        "boreholes": []
    }
    for s in selected:
        info = s["info"]
        result["boreholes"].append({
            "\u5b54\u865f": s["holePointNo"],
            "\u65b9\u4f4d": s["sector"],
            "\u8ddd\u96e2m": s["dist"],
            "\u6df1\u5ea6m": s["depth"],
            "\u5730\u8868\u9ad8\u7a0bm": info.get('\u947d\u5b54\u5730\u8868\u9ad8\u7a0b', '-'),
            "\u947d\u63a2\u65e5\u671f": s["dateStr"],
            "\u947d\u63a2\u516c\u53f8": info.get('\u947d\u63a2\u516c\u53f8', '-'),
            "\u8a08\u756b\u540d\u7a31": s["projName"],
            "\u5ea7\u6a19\u7cfb\u7d71": info.get('\u5ea7\u6a19\u7cfb\u7d71', '-'),
            "X\u5ea7\u6a19": info.get('\u5b54\u53e3X\u5ea7\u6a19', '-'),
            "Y\u5ea7\u6a19": info.get('\u5b54\u53e3Y\u5ea7\u6a19', '-'),
            "\u5716\u7246\u6709\u7121_\u8cc7\u6599\u5eab\u6a19\u8a3b": s["imageExist"],
            "keyid": s["keyid"],
            "projectKeyid": s["projectKeyid"],
        })
    return result


async def _query_boreholes_internal(lat, lon, radius_m=200):
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser, page = await _new_page(p)
        try:
            return await _query_boreholes_on_page(page, lat, lon, radius_m)
        finally:
            await browser.close()


# ===== GeoReport Fetch via real WebWorker =====
#
# The Chart endpoint (POST /api/GeoReport Mode=Chart) is WAF-filtered to
# requests that come from a WebWorker context. Main-thread fetch gets a
# bare 404 (no content-type), because the browser auto-adds Origin/
# Sec-Fetch-* on main-thread requests but not on Worker-originated ones,
# and the WAF rejects anything with those headers.
#
# Rather than trying to strip those headers client-side, we spawn the
# site's own WebWorker (same-origin, so it inherits proper Referer:
# GetGeoReport.js) and postMessage into it. The worker's code is 5 lines:
#
#   self.onmessage = function (e) {
#       importScripts('AjaxPost.js');
#       ycgis.AjaxPost({url:'../../api/GeoReport', param: e.data, ...});
#   };
#
# v4.10: the same Worker transport serves Mode=Chart, Mode=Test, and
# Mode=BaseData. Mode is passed through args.mode.

GEOREPORT_WORKER_JS = r"""
async (args) => {
    return await new Promise((resolve) => {
        let settled = false;
        const timer = setTimeout(() => {
            if (!settled) {
                settled = true;
                resolve({status: 'timeout'});
            }
        }, 30000);

        try {
            const worker = new Worker(
                '/imoeagis/js/WebWorker/GetGeoReport.js?v=' + Date.now()
            );
            worker.onmessage = (e) => {
                if (settled) return;
                settled = true;
                clearTimeout(timer);
                resolve({status: 'ok', data: e.data});
                worker.terminate();
            };
            worker.onerror = (err) => {
                if (settled) return;
                settled = true;
                clearTimeout(timer);
                resolve({
                    status: 'worker_error',
                    message: err.message || '(no message)',
                    filename: err.filename,
                    lineno: err.lineno
                });
                worker.terminate();
            };
            worker.postMessage({
                Mode: args.mode,
                ProjectKeyId: args.pk,
                KeyId: args.kid
            });
        } catch (e) {
            settled = true;
            clearTimeout(timer);
            resolve({status: 'exception', message: e.message});
        }
    });
}
"""


def _parse_chart_pages(data, compress_mode="mono"):
    """Convert the server's response (array of HTML strings containing
    `<a href="data:image/emf;base64, <PNG_BASE64>">`) into a list of
    data URLs. The server labels it emf but the actual bytes are PNG.

    compress_mode: 'mono'(預設,單色1-bit,最小) / 'color256' / 'none'。
    柱狀圖以文字+N值判讀為主，單色已足夠且單頁僅 ~10KB。"""
    if not isinstance(data, list) or not data:
        return []
    pages = []
    for html in data:
        if not html:
            continue
        m = re.search(r'base64,\s*([A-Za-z0-9+/=\s]+?)(?=")', html)
        if not m:
            # fall back to greedy (no trailing quote in edge case)
            m = re.search(r'base64,\s*([A-Za-z0-9+/=\s]+)', html)
        if m:
            b64 = re.sub(r'\s+', '', m.group(1))
            url = 'data:image/png;base64,' + b64
            if compress_mode and compress_mode != "none":
                url = _compress_page_data_url(url, mode=compress_mode)
            pages.append(url)
    return pages


# ===== Test (試驗資料) HTML Parser =====
#
# Mode=Test returns an array; element [0] is an HTML string with nested
# Bootstrap accordion structure. Each test (T-1, T-2, ...) is a panel
# with TWO tables:
#
#   <div class="panel panel-default">
#     <div class="panel-heading">             ← summary table
#       <table>
#         <thead><tr><td>試驗編號</td><td>試驗中文名稱</td>...</tr></thead>
#         <tbody><tr><td>T-1</td><td>土壤一般物理性質試驗</td>...</tr></tbody>
#       </table>
#     </div>
#     <div class="panel-collapse">             ← detail table (the good stuff)
#       <table>
#         <thead><tr><th>取樣編號</th><th>上限深度</th><th>下限深度</th>
#                    <th>統一土壤分類</th><th>含水量</th><th>液性限度</th>
#                    <th>塑性限度</th><th>塑性指數</th><th>比重</th>
#                    <th>礫石</th><th>砂</th><th>細料</th>
#                    <th>統體單位重</th><th>空隙比</th></tr></thead>
#         <tbody>
#           <tr><td>S-17</td><td>25.05</td><td>25.50</td><td>SM</td>...</tr>
#           <tr><td>S-18</td>...</tr>
#           ...  ← many rows, one per sample
#         </tbody>
#       </table>
#     </div>
#   </div>
#
# We extract (a) the summary row to label the test, and (b) ALL rows of
# the detail table (one record per sample). Each output record carries
# the parent 試驗編號/試驗中文名稱 so downstream consumers don't need to
# look them up.

def _parse_test_data(data):
    """Parse Mode=Test HTML into a list of per-sample test records.

    Each record is one lab sample (e.g. S-17) with its own USCS,
    depth range, water content, LL/PI, Atterberg limits, grading, etc.
    Records are tagged with the parent 試驗編號 (e.g. T-1) so you can
    tell which test family they belong to.

    Returns:
        [
            {試驗編號, 試驗中文名稱, 取樣編號, 上限深度m, 下限深度m,
             USCS, 含水量%, LL, PL, PI, 比重, 礫石%, 砂%, 細料%, ...},
            ...
        ]
    """
    if not isinstance(data, list) or not data:
        return []
    html = data[0] if data[0] else ''
    if not html:
        return []

    # Slice the HTML into per-test panels by depth-counting <div> tags,
    # since nested div regex is unreliable. Starting positions are marked
    # by `<div class="panel panel-default">`.
    panel_open_re = re.compile(r'<div class=["\']panel panel-default["\']')
    starts = [m.start() for m in panel_open_re.finditer(html)]

    def slice_panel(start):
        """Walk <div>/</div> depth from `start` and return the panel's end index."""
        pos = start
        depth = 0
        while pos < len(html):
            open_i = html.find('<div', pos)
            close_i = html.find('</div>', pos)
            if open_i == -1 and close_i == -1:
                return len(html)
            if open_i != -1 and (close_i == -1 or open_i < close_i):
                depth += 1
                pos = open_i + 4
            else:
                depth -= 1
                pos = close_i + 6
                if depth == 0:
                    return pos
        return len(html)

    results = []

    for start in starts:
        end = slice_panel(start)
        panel_html = html[start:end]

        # --- (a) Summary table in panel-heading: extract 試驗編號 and name
        heading_m = re.search(
            r'<div class=["\']panel-heading.*?</div>\s*</div>',
            panel_html, re.DOTALL
        )
        test_id = ''
        test_name = ''
        if heading_m:
            heading = heading_m.group(0)
            thead_m = re.search(r'<thead>(.*?)</thead>', heading, re.DOTALL)
            tbody_m = re.search(r'<tbody>(.*?)</tbody>', heading, re.DOTALL)
            if thead_m and tbody_m:
                headers = [
                    re.sub(r'<[^>]+>', '', c).strip()
                    for c in re.findall(
                        r'<t[dh][^>]*>(.*?)</t[dh]>',
                        thead_m.group(1), re.DOTALL
                    )
                ]
                row_m = re.search(r'<tr[^>]*>(.*?)</tr>', tbody_m.group(1), re.DOTALL)
                if row_m:
                    values = [
                        re.sub(r'<[^>]+>', '', c).strip()
                        for c in re.findall(
                            r'<t[dh][^>]*>(.*?)</t[dh]>',
                            row_m.group(1), re.DOTALL
                        )
                    ]
                    summary = dict(zip(headers, values))
                    test_id = summary.get('試驗編號', '')
                    test_name = summary.get('試驗中文名稱', '')

        # --- (b) Detail table in panel-collapse: one row per sample
        collapse_m = re.search(
            r'<div[^>]*class=["\'][^"\']*panel-collapse[^"\']*["\'][^>]*>(.*)',
            panel_html, re.DOTALL
        )
        if not collapse_m:
            continue
        collapse_html = collapse_m.group(1)

        thead_m = re.search(r'<thead>(.*?)</thead>', collapse_html, re.DOTALL)
        tbody_m = re.search(r'<tbody>(.*?)</tbody>', collapse_html, re.DOTALL)
        if not (thead_m and tbody_m):
            continue

        # Headers may contain <br/>, units in parens — collapse whitespace/newlines
        headers = []
        for c in re.findall(r'<t[dh][^>]*>(.*?)</t[dh]>', thead_m.group(1), re.DOTALL):
            txt = re.sub(r'<br\s*/?>', ' ', c)
            txt = re.sub(r'<[^>]+>', '', txt)
            txt = re.sub(r'\s+', ' ', txt).strip()
            headers.append(txt)

        if not headers:
            continue

        for row_m in re.finditer(r'<tr[^>]*>(.*?)</tr>', tbody_m.group(1), re.DOTALL):
            values = [
                re.sub(r'<[^>]+>', '', c).strip()
                for c in re.findall(
                    r'<t[dh][^>]*>(.*?)</t[dh]>',
                    row_m.group(1), re.DOTALL
                )
            ]
            if len(values) != len(headers) or not any(values):
                continue
            record = dict(zip(headers, values))
            record['試驗編號'] = test_id
            record['試驗中文名稱'] = test_name
            results.append(record)

    return results


# ===== GeoReport fetchers (on an existing page) =====

async def _fetch_georeport_on_page(page, keyid, project_keyid, mode):
    """Fetch GeoReport in any mode on an existing page.
    page must already be on the geotech map for same-origin Worker loading."""
    await _goto_map(page)
    result = await page.evaluate(
        GEOREPORT_WORKER_JS,
        {"pk": project_keyid, "kid": keyid, "mode": mode}
    )
    if not result or result.get("status") != "ok":
        return {
            "status": result.get("status", "unknown") if result else "null_result",
            "message": (result or {}).get("message", ""),
        }
    return {"status": "ok", "data": result.get("data")}


async def _fetch_chart_on_page(page, keyid, project_keyid):
    """Fetch Mode=Chart on an existing page, parse into data-URL pages."""
    r = await _fetch_georeport_on_page(page, keyid, project_keyid, "Chart")
    if r["status"] != "ok":
        return r
    pages = _parse_chart_pages(r["data"])
    if not pages:
        return {"status": "empty", "pages": []}
    return {"status": "ok", "pages": pages}


async def _fetch_test_on_page(page, keyid, project_keyid):
    """Fetch Mode=Test on an existing page, parse into structured records."""
    r = await _fetch_georeport_on_page(page, keyid, project_keyid, "Test")
    if r["status"] != "ok":
        return r
    tests = _parse_test_data(r["data"])
    return {"status": "ok", "tests": tests}


async def _fetch_basedata_on_page(page, keyid, project_keyid):
    """Fetch Mode=BaseData on an existing page, parse into a key→value dict."""
    r = await _fetch_georeport_on_page(page, keyid, project_keyid, "BaseData")
    if r["status"] != "ok":
        return r
    data = r["data"]
    if not isinstance(data, list) or not data or not data[0]:
        return {"status": "empty", "base_data": {}}
    html = data[0]
    info = {}
    for tr_m in re.finditer(r'<tr[^>]*>(.*?)</tr>', html, re.DOTALL):
        tr = tr_m.group(1)
        th_m = re.search(r'<th[^>]*>(.*?)</th>', tr, re.DOTALL)
        td_m = re.search(r'<td[^>]*>(.*?)</td>', tr, re.DOTALL)
        if th_m and td_m:
            key = re.sub(r'<[^>]+>', '', th_m.group(1)).strip()
            val = re.sub(r'<[^>]+>', '', td_m.group(1)).strip()
            if key:
                info[key] = val
    return {"status": "ok", "base_data": info}


async def _fetch_chart_base64(keyid, project_keyid):
    """Standalone single-chart fetch: opens its own browser."""
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser, page = await _new_page(p)
        try:
            return await _fetch_chart_on_page(page, keyid, project_keyid)
        finally:
            await browser.close()


def _sanitize_for_path(s):
    """Remove characters that can't appear in file/directory names.
    Preserves Chinese characters and 巷/弄/號, per input_format.md spec."""
    # Strip whitespace and common ASCII punctuation; keep everything else
    # (including CJK) so 松江路131巷5弄3號 stays intact.
    return re.sub(r'[\s,;:\'"/\\|<>?*]', '', s or '')


def _project_output_dir(address):
    """Build the project-level output path: ./geotech_output/<addr>_<date>/.
    Mirrors the filename spec from input_format.md."""
    safe_addr = _sanitize_for_path(address) or "noaddr"
    date_str = datetime.now().strftime("%Y%m%d")
    base = Path("geotech_output") / f"{safe_addr}_{date_str}"
    return base


def _write_chart_pngs(pages, project_dir, hole_no, sector):
    """Decode base64 data-URLs and write each page to disk.
    Returns list of file paths (as strings, relative to cwd)."""
    charts_dir = project_dir / "charts"
    charts_dir.mkdir(parents=True, exist_ok=True)
    safe_hole = _sanitize_for_path(hole_no) or "unknown"
    safe_sector = sector or "NA"
    saved = []
    for i, data_url in enumerate(pages):
        if not data_url:
            continue
        # data_url is "data:image/png;base64,<BASE64>"
        b64 = data_url.split(",", 1)[-1]
        try:
            png_bytes = base64.b64decode(b64)
        except Exception:
            continue
        fname = f"{safe_hole}_{safe_sector}_p{i+1}.png"
        fpath = charts_dir / fname
        with open(fpath, "wb") as f:
            f.write(png_bytes)
        saved.append(str(fpath))
    return saved


def _build_chart_response(hole_no, sector, dist_m, keyid, project_keyid,
                          pages, chart_mode="inline", project_dir=None):
    """Build the per-borehole response payload.

    chart_mode:
        'inline'   — base64 data URLs in the response (default).
        'save'     — write PNG files to <project_dir>/charts/ and return paths.
        'metadata' — page count only, no image data, no files.
    """
    base = {
        "\u5b54\u865f": hole_no,
        "\u65b9\u4f4d": sector,
        "\u8ddd\u96e2m": dist_m,
        "keyid": keyid,
        "projectKeyid": project_keyid,
        "\u67f1\u72c0\u5716\u9801\u6578": len(pages),
    }

    if chart_mode == "metadata":
        base["\u5224\u8b80\u8aaa\u660e"] = (
            "chart_mode=metadata: page count only, no image data. "
            "Re-run with chart_mode='inline' or 'save' to retrieve images."
        )
        return base

    if chart_mode == "save":
        if project_dir is None:
            project_dir = Path("geotech_output") / "standalone"
        saved_paths = _write_chart_pngs(pages, project_dir, hole_no, sector)
        base["\u67f1\u72c0\u5716\u6a94\u6848"] = saved_paths  # 柱狀圖檔案
        base["\u5224\u8b80\u8aaa\u660e"] = (
            "chart_mode=save: PNG files written to disk. "
            "Paths are relative to the MCP server's working directory. "
            "Open each file or pass to Vision analysis manually."
        )
        return base

    # default: inline
    base["\u67f1\u72c0\u5716"] = [
        {"page": i+1, "image_base64": p}
        for i, p in enumerate(pages) if p
    ]
    base["\u5224\u8b80\u8aaa\u660e"] = (
        "Please analyze the boring log images (base64 PNG) and extract:\n"
        "1. Soil layers: depth range, thickness, description, color, USCS\n"
        "2. SPT-N values at each depth\n"
        "3. Groundwater level (GWL)\n"
        "4. Surface elevation\n"
        "Return as structured JSON."
    )
    return base


# ===== MCP Tools =====

@mcp.tool()
async def query_boreholes(lat: float, lon: float, radius_m: float = 200) -> str:
    """
    Query boreholes near given coordinates.
    Selects best 1 borehole per 8 compass directions.
    Preference: nearest > deepest > newest.
    Auto-expands radius (200→500→1000m) if no results found.
    Returns keyid/projectKeyid for chart retrieval.
    Note: imageExist flag from the DB is unreliable and no longer used
    for selection; always attempt chart fetch regardless of its value.
    """
    result = await _query_boreholes_internal(lat, lon, radius_m)
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def query_boreholes_by_address(address: str, radius_m: float = 200) -> str:
    """
    Query boreholes near a given address.
    Geocodes address via Google Maps, then queries borehole database.
    Selects best 1 borehole per 8 compass directions.
    Returns keyid/projectKeyid for chart retrieval.
    """
    geo = await geocode_address(address)
    if "error" in geo:
        return json.dumps({"error": "geocoding failed", "detail": geo["error"]}, ensure_ascii=False, indent=2)
    result = await _query_boreholes_internal(geo["lat"], geo["lon"], radius_m)
    result["address"] = address
    result["geocoded_url"] = geo.get("url", "")
    return json.dumps(result, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_borehole_chart(
    keyid: str,
    project_keyid: str,
    hole_no: str = "",
    chart_mode: str = "inline"
) -> str:
    """
    Fetch boring log chart image (base64 PNG) for a single borehole.
    Uses a WebWorker-originated request to satisfy the server's WAF.

    chart_mode:
      'inline'   — base64 data URLs in response (for Vision analysis).
      'save'     — write PNG files to ./geotech_output/standalone/charts/
                   and return paths only (small response).
      'metadata' — page count only; no image data.

    Get keyid/project_keyid from query_boreholes or query_boreholes_by_address.
    """
    r = await _fetch_chart_base64(keyid, project_keyid)
    if r["status"] == "ok":
        project_dir = Path("geotech_output") / "standalone" if chart_mode == "save" else None
        result = _build_chart_response(
            hole_no or keyid, "", 0, keyid, project_keyid, r["pages"],
            chart_mode=chart_mode, project_dir=project_dir
        )
        return json.dumps(result, ensure_ascii=False, indent=2)
    if r["status"] == "empty":
        return json.dumps({
            "error": "no chart available",
            "hole_no": hole_no or keyid,
            "note": "no chart image in database for this borehole"
        }, ensure_ascii=False, indent=2)
    return json.dumps({
        "error": "chart fetch failed",
        "hole_no": hole_no or keyid,
        "reason": r.get("status"),
        "detail": r.get("message", "")
    }, ensure_ascii=False, indent=2)


@mcp.tool()
async def get_borehole_full_data(
    keyid: str,
    project_keyid: str,
    hole_no: str = "",
    include_test: bool = True,
    chart_mode: str = "inline"
) -> str:
    """
    Fetch complete data for a single borehole: BaseData + Chart + Test.

    BaseData: authoritative header info (hole no, total depth, elevation,
              coordinates, drilling company, dates).
    Chart:    boring log PNG pages for Vision analysis. Format controlled
              by chart_mode (see below).
    Test:     laboratory test records (USCS, water content, LL, PI, etc.)
              per sample depth. Set include_test=False to skip for speed.

    chart_mode:
      'inline'   — base64 data URLs in response (default, for Vision).
      'save'     — write PNG files to ./geotech_output/standalone/charts/.
      'metadata' — page count only.

    Use this when you need the most complete picture of a single borehole —
    e.g. cross-validating Vision-extracted layers against BaseData, or
    overlaying Atterberg limits onto the chart.
    """
    from playwright.async_api import async_playwright
    async with async_playwright() as p:
        browser, page = await _new_page(p)
        try:
            base_r = await _fetch_basedata_on_page(page, keyid, project_keyid)
            chart_r = await _fetch_chart_on_page(page, keyid, project_keyid)
            test_r = None
            if include_test:
                test_r = await _fetch_test_on_page(page, keyid, project_keyid)

            result = {
                "\u5b54\u865f": hole_no or str(keyid),
                "keyid": keyid,
                "projectKeyid": project_keyid,
                "\u57fa\u672c\u8cc7\u6599": (
                    base_r.get("base_data") if base_r.get("status") == "ok" else None
                ),
                "\u57fa\u672c\u8cc7\u6599_\u72c0\u614b": base_r.get("status"),
                "\u67f1\u72c0\u5716_\u72c0\u614b": chart_r.get("status"),
                "\u67f1\u72c0\u5716_\u9801\u6578": (
                    len(chart_r.get("pages", [])) if chart_r.get("status") == "ok" else 0
                ),
            }

            # Chart payload honours chart_mode
            pages = chart_r.get("pages", []) if chart_r.get("status") == "ok" else []
            if pages:
                if chart_mode == "metadata":
                    pass  # page count already included above
                elif chart_mode == "save":
                    project_dir = Path("geotech_output") / "standalone"
                    saved = _write_chart_pngs(pages, project_dir,
                                              hole_no or str(keyid), "")
                    result["\u67f1\u72c0\u5716\u6a94\u6848"] = saved
                else:  # inline
                    result["\u67f1\u72c0\u5716"] = [
                        {"page": i+1, "image_base64": p}
                        for i, p in enumerate(pages)
                    ]

            if include_test and test_r is not None:
                result["\u8a66\u9a57\u8cc7\u6599_\u72c0\u614b"] = test_r.get("status")
                result["\u8a66\u9a57\u8cc7\u6599"] = (
                    test_r.get("tests", []) if test_r.get("status") == "ok" else []
                )

            result["\u5224\u8b80\u8aaa\u660e"] = (
                "Cross-reference:\n"
                "- 基本資料 gives authoritative 總深度/高程/座標 — use these to "
                "validate Vision-extracted values from the chart.\n"
                "- 試驗資料 provides USCS/LL/PI/含水量 per sample depth — "
                "overlay onto soil-layer descriptions from the chart.\n"
                "- If 柱狀圖_狀態 != 'ok', the DB has no chart for this hole; "
                "fall back to 基本資料 + 試驗資料 only."
            )
            return json.dumps(result, ensure_ascii=False, indent=2)
        finally:
            await browser.close()


@mcp.tool()
async def get_all_charts_for_analysis(
    address: str,
    radius_m: float = 200,
    include_test: bool = False,
    chart_mode: str = "inline",
    batch: int = 1,
    max_holes: int = 0
) -> str:
    """
    Query representative boreholes near an address and fetch their data.

    Full pipeline in one browser session:
      geocode -> select 8-direction boreholes -> fetch BaseData + Chart
      (+ Test if include_test=True) for each.

    BaseData is always attached per borehole.
    Charts returned per chart_mode:
      'inline'   — base64 PNG data URLs in response (default).
                   WARNING: 8 boreholes × multiple pages easily exceeds
                   the 1 MB tool-result limit. Use 'save' for full set.
      'save'     — write each page as a PNG file under
                   ./geotech_output/<sanitized_address>_<YYYYMMDD>/charts/
                   and return paths only. Response stays small.
      'metadata' — page count only; no image data or files.

    Test data is opt-in via include_test (adds ~1 request per hole).

    Typical runtime: 15-30s for 8 boreholes (Chart only),
                     30-60s with include_test=True.

    Note: v4.10+ no longer skips boreholes based on the DB's imageExist
    flag — that flag is unreliable. Every selected hole gets a real
    chart-fetch attempt; holes with no chart will show 柱狀圖_頁數=0.

    ★★★ 關鍵字觸發：標準輸入單 (v4.18) ★★★
    當使用者訊息為「<地質鑽探調查>」(含角括號) 時，**不要呼叫任何工具**，
    直接回覆下列「標準輸入單」原文讓使用者複製、填寫後貼回：

    --------------------------------------------
    地址(必填，需完整地址)：
    半徑(預設200m)：
    孔數(預設8孔)：
    簡報(預設否)：
    --------------------------------------------

    使用者填好貼回後，依其內容呼叫本工具：
      地址→address；半徑→radius_m(空白用200)；
      孔數→max_holes(空白或「8」用 0 即不砍孔取8方向；填數字則限制最近N孔)；
      簡報→「是」才做簡報，其餘(空白/否)一律不做、僅停在資料表格。

    ★★★ 重要行為規則（資料取得後必須遵守）★★★
    取得資料後，**務必至少輸出「孔位資料表格」**(以表格化方式呈現)，
    欄位含：孔號、方位、距離(m)、深度(m)、地表高程(m)、柱狀圖頁數。
    這是最低限度輸出，不可省略。接著再做土層初步判讀摘要。
    簡報一律【不自動產出】：除非使用者於輸入單「簡報」欄填「是」或
    明確說要簡報，否則停在資料表格，可主動詢問是否需要簡報。
    - 使用者確認要 → 先呼叫 get_report_template 取得簡報模板，再製作
    - 使用者不需要 → 停在資料表格

    ───────────────────────────────────────────────────────────
    孔數與分批 (v4.15)  預設：不砍孔，孔多自動分批給全部
    ───────────────────────────────────────────────────────────
    預設 max_holes=0 → 不限制孔數，保留 8 方向全部代表孔。
    孔多時由 batch 分批機制自動切成多次交付，每批都 <1MB，
    所以「孔數一個不少，只是分幾次端上來」。呼叫端依回應的
    batch_plan.next_call 逐批取完即可。

    max_holes>0：手動限制只抓最近 N 孔(先選 8 方向代表孔，再取
    最近 N 孔)。僅在你想刻意少抓、一次拿少量時使用。一般不需要。

    ───────────────────────────────────────────────────────────
    分批 inline (v4.13)  ※ 僅 chart_mode='inline' 適用
    ───────────────────────────────────────────────────────────
    8 孔多頁 base64 一次回傳會超過 1 MB 上限。本工具改為自動分批：
      - 第一次呼叫 (batch=1)：抓圖一次、存入行程內快取，回傳
        『batch_plan』(共幾批、本批孔號) + 第 1 批的圖。
      - 若 batch_plan.total_batches > 1，呼叫端再以 batch=2,3...
        重複呼叫(其餘參數不變)取得後續批次，直接命中快取、不重抓。
    回應內 batch_plan 欄位：
      { "current": N, "total_batches": M, "has_more": bool,
        "this_batch_holes": [...], "next_call": "batch=N+1" }
    metadata / save 模式不分批(回應本來就小)，batch 參數忽略。
    """
    from playwright.async_api import async_playwright

    # ── 分批快取快速路徑 (inline 專用) ──
    # 若已有快取(同 address/radius/include_test)，直接切出指定批次回傳，
    # 不重新抓圖。涵蓋 batch>=2 的後續取用，以及 batch=1 的重複呼叫。
    if chart_mode == "inline":
        ck = _cache_key(address, radius_m, include_test)
        cached = _cache_get(ck)
        if cached is not None:
            return _emit_batch(cached, batch)

    geo = await geocode_address(address)
    if "error" in geo:
        return json.dumps({"error": "geocoding failed", "detail": geo["error"]}, ensure_ascii=False, indent=2)

    # In save mode, build the project output directory now so we can
    # report its path in the summary, and pass it to the chart writer.
    project_dir = None
    if chart_mode == "save":
        safe_addr = _sanitize_for_path(address) or "noaddr"
        date_str = datetime.now().strftime("%Y%m%d")
        project_dir = Path("geotech_output") / f"{safe_addr}_{date_str}"
        (project_dir / "charts").mkdir(parents=True, exist_ok=True)

    # Single browser session for borehole query + all fetches.
    async with async_playwright() as p:
        browser, page = await _new_page(p)
        try:
            bh_result = await _query_boreholes_on_page(page, geo["lat"], geo["lon"], radius_m, max_holes)
            if "error" in bh_result:
                bh_result["address"] = address
                return json.dumps(bh_result, ensure_ascii=False, indent=2)

            results = []
            for bh in bh_result.get("boreholes", []):
                keyid = bh.get("keyid")
                project_keyid = bh.get("projectKeyid")
                hole_no = bh.get("\u5b54\u865f", str(keyid))
                sector = bh.get("\u65b9\u4f4d", "")
                dist = bh.get("\u8ddd\u96e2m", 0)

                entry = {
                    "\u5b54\u865f": hole_no,
                    "\u65b9\u4f4d": sector,
                    "\u8ddd\u96e2m": dist,
                    "keyid": keyid,
                    "projectKeyid": project_keyid,
                    # Re-attach the query-phase BaseData (already fetched during
                    # borehole selection — no extra roundtrip).
                    "\u57fa\u672c\u8cc7\u6599": {
                        k: bh.get(k) for k in [
                            "\u6df1\u5ea6m", "\u5730\u8868\u9ad8\u7a0bm",
                            "\u947d\u63a2\u65e5\u671f", "\u947d\u63a2\u516c\u53f8",
                            "\u8a08\u756b\u540d\u7a31", "\u5ea7\u6a19\u7cfb\u7d71",
                            "X\u5ea7\u6a19", "Y\u5ea7\u6a19",
                        ] if bh.get(k) is not None
                    },
                    "\u5716\u7246\u6709\u7121_\u8cc7\u6599\u5eab\u6a19\u8a3b":
                        bh.get("\u5716\u7246\u6709\u7121_\u8cc7\u6599\u5eab\u6a19\u8a3b", ""),
                }

                if not keyid or not project_keyid:
                    entry["error"] = "missing keyid"
                    results.append(entry)
                    continue

                # Always try to fetch the chart (v4.10+: no imageExist skip).
                chart_r = await _fetch_chart_on_page(page, keyid, project_keyid)
                entry["\u67f1\u72c0\u5716_\u72c0\u614b"] = chart_r.get("status")
                if chart_r["status"] == "ok":
                    pages = chart_r["pages"]
                    entry["\u67f1\u72c0\u5716\u9801\u6578"] = len(pages)
                    if chart_mode == "metadata":
                        pass  # no payload beyond page count
                    elif chart_mode == "save":
                        saved = _write_chart_pngs(pages, project_dir, hole_no, sector)
                        entry["\u67f1\u72c0\u5716\u6a94\u6848"] = saved
                    else:  # inline
                        entry["\u67f1\u72c0\u5716"] = [
                            {"page": i+1, "image_base64": pg}
                            for i, pg in enumerate(pages) if pg
                        ]
                elif chart_r["status"] == "empty":
                    entry["\u67f1\u72c0\u5716\u9801\u6578"] = 0
                    entry["_\u8a3b\u8a18"] = "資料庫內無此孔柱狀圖"
                else:
                    entry["\u67f1\u72c0\u5716\u9801\u6578"] = 0
                    entry["_\u8a3b\u8a18"] = chart_r.get("message", "")

                if include_test:
                    test_r = await _fetch_test_on_page(page, keyid, project_keyid)
                    entry["\u8a66\u9a57\u8cc7\u6599_\u72c0\u614b"] = test_r.get("status")
                    entry["\u8a66\u9a57\u8cc7\u6599"] = (
                        test_r.get("tests", []) if test_r.get("status") == "ok" else []
                    )

                results.append(entry)

            with_chart = sum(1 for r in results if r.get("\u67f1\u72c0\u5716\u9801\u6578", 0) > 0)
            without_chart = len(results) - with_chart
            with_test = sum(1 for r in results if len(r.get("\u8a66\u9a57\u8cc7\u6599", [])) > 0) \
                        if include_test else None

            # summary_head：所有「不含每孔圖片」的摘要欄位。分批時每批都附帶它，
            # 讓任一批回應都能獨立看懂地址/孔數統計等脈絡。
            summary_head = {
                "address": address,
                "address_lat": geo["lat"],
                "address_lon": geo["lon"],
                "radius_m": bh_result["radius_m"],
                "chart_mode": chart_mode,
                "total_boreholes": len(results),
                "max_holes": max_holes,
                "capped_to_nearest": bh_result.get("capped_to_nearest", False),
                "boreholes_with_chart": with_chart,
                "boreholes_without_chart": without_chart,
                "include_test": include_test,
                "note": (
                    "Analyze each borehole's 柱狀圖 for soil layers, SPT-N, GWL. "
                    "Cross-reference with 基本資料 for authoritative depth/elevation."
                ),
                "下一步": (
                    "請至少以表格輸出孔位資料(孔號/方位/距離/深度/高程/柱狀圖頁數)。"
                    "簡報不自動產出：使用者輸入單『簡報』欄填『是』才做，否則停在表格。"
                ),
            }
            if include_test:
                summary_head["boreholes_with_test_data"] = with_test

            # metadata / save：回應本來就小，維持單次回傳(不分批)。
            if chart_mode != "inline":
                summary = dict(summary_head)
                summary["boreholes"] = results
                if project_dir is not None:
                    summary["output_dir"] = str(project_dir)
                return json.dumps(summary, ensure_ascii=False, indent=2)

            # inline：抓圖已完成(只此一次)。裝箱、存快取、回傳第 1 批。
            import time
            batches = _pack_batches(results)
            ck = _cache_key(address, radius_m, include_test)
            _CHART_CACHE[ck] = {
                "summary_head": summary_head,
                "entries": results,
                "batches": batches,
                "created": time.time(),
            }
            return _emit_batch(_CHART_CACHE[ck], batch)
        finally:
            await browser.close()


@mcp.tool()
async def get_geotech_input_form() -> str:
    """地質鑽探調查的『標準輸入單』。

    ★ 觸發時機（務必呼叫此工具）：
      只要使用者訊息為「<地質鑽探調查>」(含角括號)，或語意上是想開始一筆
      地質鑽探查詢但尚未給地址，就【呼叫本工具】取得標準輸入單，
      並將回傳內容【逐字、原封不動】貼給使用者，不要改寫、不要自行增減欄位、
      不要改問其他問題（例如不要問『查詢目的』）。

    回傳：固定格式的四欄輸入單純文字。
    """
    return (
        "請複製下方輸入單，填寫後貼回即可開始查詢：\n\n"
        "--------------------------------------------\n"
        "地址(必填，需完整地址)：\n"
        "半徑(預設200m)：\n"
        "孔數(預設8孔)：\n"
        "簡報(預設否)：\n"
        "--------------------------------------------"
    )


@mcp.tool()
async def get_report_template() -> str:
    """
    取得 PPT 簡報報告的格式規範（投影片結構、版面、配色、製作原則）。

    ★ 何時呼叫：當使用者「確認需要製作 PPT 簡報」後，呼叫此工具
      取得完整規範，再依規範製作簡報。

    ★ 製作方式（重要）：優先以安裝包內的『簡報範本.pptx』為範本，
      用 pptx 編輯方式複製範本、只替換資料，不要從零排版。
      每份簡報務必包含『鑽孔資料表』（孔號/方位/距離/深度），絕不可省略。

    回傳：4 張投影片（無封面）的結構、配色、字型、資料運用與計算原則。
    """
    template = {
        "★最優先規則（務必先讀，違反即錯）": {
            "1_使用範本檔複製改數字": "製作簡報時，優先以安裝包內的『簡報範本.pptx』為範本，"
                "用 pptx 編輯方式『複製範本、只替換其中的資料（孔號/方位/距離/深度/土層/N值/"
                "柱狀圖/標題）』，不要從零自行排版。範本已是正確版型（4:3、藍色系、微軟正黑體、"
                "母片LOGO、4頁結構），照填即可確保與範例一致。範本路徑與安裝目錄同層或安裝包內。",
            "2_必含鑽孔資料表": "每份簡報【一定要】包含一張『鑽孔資料表』投影片（即範本第1頁右側與"
                "第4頁的表格），欄位固定為：孔號、方位、距離、深度、地表高程(或柱狀圖)。"
                "這張表【絕不可省略】，是簡報的最低必要內容。即使其他頁省略，這張表也要在。",
            "3_四頁結構": "固定 4 頁、無封面：①鑽孔位置與基地水平關係（含孔位表）"
                "②土層綜合剖面（彩色分層）③代表孔柱狀圖（嵌真實原圖）④鑽孔資料總表與判讀。",
            "4_資料來源": "表格與判讀的數字一律來自本次查詢實得資料，不可沿用範本的範例值"
                "（範本中的 BH-3/BH-2 等為示意，需全部換成本案實際孔號與數據）。"
        },
        "投影片數量": 4,
        "配色": {
            "標題文字": "1F2A3A 近黑藍",
            "主輔色": "385D8A 藍",
            "次輔色": "4F81BD 淺藍",
            "卡片底": "EAF0F7 淺藍灰",
            "內容區背景": "FFFFFF 白",
            "基地標記": "E8821E 橙菱形",
            "回填層": "D6DCE5 淺灰藍",
            "砂_粉土質砂": "E8C97A 砂黃",
            "粉土質黏土": "A9C0D6 藍",
            "卵礫石": "9C8A5E 褐"
        },
        "字型": {
            "投影片標題": "思源黑體 Bold 28~36pt",
            "區段標題": "思源黑體 Bold 18~22pt",
            "內文": "思源黑體 Regular 12~16pt",
            "大數字": "思源黑體 Bold 40~60pt"
        },
        "投影片": [
            {
                "頁": 1, "標題": "鑽孔位置與基地水平關係",
                "版面": "白底，標題列藍字，左圖右表",
                "內容": "左側位置圖（基地置中橙色菱形，各孔圓點依方位+距離擺位，有圖實心藍/無圖空心灰，"
                        "100m半徑虛線圈，比例尺+指北針，孔點旁標孔號+方位+距離）；"
                        "右側『鑽孔資料表』（孔號/方位/距離/深度/圖；有圖✓無圖—）；下方圖例。"
                        "【此頁的右側表格為必含的鑽孔資料表，不可省略】"
            },
            {
                "頁": 2, "標題": "土層綜合剖面",
                "版面": "白底，標題列藍字，兩孔剖面並排",
                "內容": "選2孔代表（優先有圖、深者）並排；縱軸深度每10m刻度、兩孔共用比例；"
                        "每孔依土層上色（回填/砂/黏土/卵礫石四色），層厚等比例；"
                        "每層標土層描述+N值+軟硬；卵礫石承載層跨孔虛線連接；右側圖例"
            },
            {
                "頁": 3, "標題": "代表孔鑽孔柱狀圖",
                "版面": "白底，標題列藍字，嵌入真實柱狀圖原圖",
                "內容": "嵌入代表孔的真實柱狀圖PNG（不重繪）；旁標孔號/方位/距離/深度；"
                        "僅對有柱狀圖的孔製作；多頁可並排"
            },
            {
                "頁": 4, "標題": "鑽孔資料總表與判讀",
                "版面": "白底，標題列藍字，左表右判讀卡",
                "內容": "左側『鑽孔資料總表』（孔號/方位/距離/深度/柱狀圖）；"
                        "右側土層分布判讀重點卡（淺層軟弱、中段漸密、承載層、液化潛勢、基礎建議）；"
                        "底部免責聲明。【左側表格為必含的鑽孔資料表，不可省略】"
            }
        ],
        "資料運用優先序": [
            "1. 基本資料 BaseData（權威值）：總深度、地表高程、座標、鑽探日期/公司",
            "2. 試驗資料 Test（實測值）：USCS、含水量、LL/PI、剪力參數、壓密參數",
            "3. 柱狀圖 Vision 判讀（補充值）：土層描述、SPT-N、地下水位",
            "衝突時以 BaseData/Test 為準"
        ],
        "缺漏處理": [
            "某方位無鑽孔 → 位置圖標『缺少』，不強制補孔",
            "某孔無柱狀圖 → 清單標 —，不做該孔柱狀圖投影片，但仍列入清單與剖面（用 Test 資料）",
            "地下水位空白 → 標『未記錄』，不臆測"
        ],
        "注意事項": [
            "簡報為初步參考，最終設計應依據原始鑽探報告正本",
            "柱狀圖原圖直接嵌入不重繪",
            "剖面圖層位連線為推測，非實測連續性"
        ],
        "★位置圖計算規範（真實製作必須認真計算，不可目測擺放）": {
            "目的": "把每個鑽孔依其相對基地的真實方位與距離，精確標在位置圖上",
            "步驟": [
                "1. 取得基地座標：以查詢回傳的 address_lat/address_lon（基地中心）為原點。",
                "2. 取得各孔座標：每孔 BaseData 內有 X座標/Y座標 與『座標系統』(TW67 或 TW97)。",
                "3. 座標系統統一：TW67 與 TW97 不可混用。若孔為 TW67，需轉為 TW97 後再計算"
                "（TW67→TW97 非單純平移，含旋轉與尺度差，須用正式七參數或官方轉換，"
                "不可用固定平移近似）。或一律將孔座標與基地經緯度轉成同一 TWD97 TM2 平面座標。",
                "4. 計算每孔相對基地的東向位移 dE、北向位移 dN（公尺）。",
                "5. 距離 = sqrt(dE^2 + dN^2)；方位角 = atan2(dE, dN)（0°=正北，順時針）。",
                "6. 驗證：算出的方位/距離須與資料庫回傳的『方位/距離m』相符（誤差過大代表座標"
                "系統或轉換有誤，須停下檢查，不可硬畫）。",
                "7. 位置圖以基地置中，依各孔 (dE, dN) 等比例縮放後標點；加比例尺、指北針、半徑虛線圈。"
            ],
            "退路": "若座標系統不明或轉換不可靠導致無法精確定位，"
                    "則退而採用資料庫已算好的『方位+距離』直接擺位（基地置中、該方位、該距離），"
                    "並於圖上註明『位置為示意，依資料庫方位距離繪製』。"
        },
        "★剖面圖計算規範": {
            "步驟": [
                "1. 縱軸為深度，0m 在頂、各孔總深度在底，固定每 10m 一刻度，各孔共用同一深度比例尺。",
                "2. 每孔依柱狀圖判讀（或 Test）之分層，自上而下逐層繪製色塊，"
                "層厚須等比例對應深度（例：1m=固定像素數），不可隨意分配。",
                "3. 各層標：土層描述 + SPT-N 值（或範圍）+ 軟硬程度。",
                "4. 卵礫石（承載層）若多孔皆達到，以跨孔虛線連接並標其出現深度/高程。",
                "5. 孔與孔之間標水平距離（取自位置圖計算結果）。",
                "6. 顏色依『配色』表之層位色，並附圖例。"
            ]
        }
    }
    return json.dumps(template, ensure_ascii=False, indent=2)


if __name__ == "__main__":
    mcp.run()
