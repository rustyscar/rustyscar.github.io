@echo off
chcp 950 >nul 2>nul
setlocal
cd /d "%~dp0"
set "OUT=%~dp0output"
set "PYDIR=Python312"
title Geotech_BH v1.04 - Fetch, Plot and Deck

REM === Detect Python ===
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe""
if not defined PY (
  echo [No Python] Please run the installer batch first.
  pause
  exit /b 1
)

echo ============================================
echo    Geotech_BH v1.04 - fetch boreholes, make plots and slides
echo ============================================
echo.
echo === Fetching: you will be prompted for the address (Python reads it; ~20-40s) ===
%PY% "%~dp0bin\geotech_cli.py" fetch --out "%OUT%"
if errorlevel 1 (
  echo.
  echo [Fetch failed or cancelled] No boreholes, address not located, or network issue.
  pause
  exit /b 1
)

echo.
echo === Plotting (azimuth/distance table + position map PNG) ===
%PY% "%~dp0bin\geotech_plot.py" --latest "%OUT%" --svg
if errorlevel 1 (
  echo [Plot failed]
  pause
  exit /b 1
)

echo.
echo === OSM map (overlay boreholes on OpenStreetMap; needs internet) ===
%PY% "%~dp0bin\geotech_osm.py" --latest "%OUT%"
if errorlevel 1 (
  echo [OSM map skipped] tile download failed or no internet. Other outputs are ready.
)

echo.
echo === Deck (build PowerPoint: position map + per-hole borehole charts + summary table) ===
%PY% "%~dp0bin\geotech_deck.py" --latest "%OUT%"
if errorlevel 1 (
  echo [Deck skipped] slide build failed. Other outputs are ready.
)

echo.
echo [Done] Opening result folder ...
start "" "%OUT%"
echo Outputs: position_map.png (schematic), position_map_osm.png (OSM), points_table.*, charts\, slides (*.pptx).
pause
