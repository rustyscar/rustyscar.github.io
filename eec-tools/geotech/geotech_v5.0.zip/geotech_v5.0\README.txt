================================================================
 Geotech v5.0  -  Nearby Borehole Query & Slide Generator
 (no-MCP edition, runs locally via Claude Code)
================================================================

WHAT IT DOES
  Given an address, it queries the government geotech database for nearby
  boreholes (8 compass directions), downloads their boring-log charts,
  helps you read the soil layers, and produces a 4-page PowerPoint summary.

REQUIREMENTS
  - Windows 10/11
  - Claude Code (already installed)
  - Python 3.10 - 3.13  (the installer will tell you if it is missing)
  - Internet connection (first run downloads the Chromium browser ~150 MB)

INSTALL (new computer)
  1. Unzip geotech_v5.0.zip anywhere.
  2. Double-click  install.bat
       - installs Python packages (playwright, pillow, python-pptx)
       - downloads the Chromium browser for Playwright
       - copies everything to:  C:\Users\<you>\Documents\Geotech
  3. Done.

USE
  1. Open Claude Code with this folder as the working directory:
       C:\Users\<you>\Documents\Geotech
  2. Type:  /geotech
  3. Fill the input form that pops up (address / radius / holes / slides).
  4. It runs: archive old -> query + fetch charts -> read logs -> (slides).

FILES
  bin\                 programs (geotech_core / geotech_cli / geotech_run) + slide template
  .claude\skills\      the "geotech" skill that drives the workflow
  examples\            example task.json
  geotech_input.txt    the input form you fill in
  output\              results land here (charts, slides); old runs move to output\OLD
  geotech_manual.html  full manual (install + usage tabs)

NOTE
  This edition does NOT use MCP. Everything runs as plain local Python,
  so there are no tool-result size limits and no MCP timeouts.

  (c) Envision Engineering Consultants  /  Geotech v5.0
