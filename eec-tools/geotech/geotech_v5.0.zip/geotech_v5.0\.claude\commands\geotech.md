---
description: 啟動 geotech 鄰近鑽孔查詢與簡報流程(無 MCP)。跳出輸入單,填完即自動執行。
---

請執行 **geotech** 技能(`.claude/skills/geotech/SKILL.md`)的完整流程。

- 若使用者尚未提供地址:**原封不動印出輸入單**(地址/半徑/孔數/簡報四欄),停下等待填寫;
  也可改讀專案根目錄的 `geotech_input.txt`。
- 若已提供(本則訊息 $ARGUMENTS 或 geotech_input.txt 已有地址):直接依 SKILL.md 步驟執行
  封存 → 查孔抓圖(全抓)→ 判讀(最深整孔+對照孔表層)→(簡報=是才)產 4 頁簡報,並回報各階段計時。

工作目錄須為本資料夾(Documents\Geotech);程式在 `bin\`,輸出在 `output\`。
