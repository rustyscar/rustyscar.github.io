@echo off
setlocal enabledelayedexpansion
title Geotech v5.0 Installer
echo ============================================
echo    Geotech v5.0 Installer  (no-MCP edition)
echo ============================================
echo.

REM --- 1. Locate Python (3.10 - 3.13 recommended) ---
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY (
  echo [ERROR] Python not found.
  echo         Install Python 3.10-3.13 from https://www.python.org/downloads/
  echo         IMPORTANT: tick "Add python.exe to PATH" during setup, then re-run this installer.
  pause
  exit /b 1
)
echo [1/5] Python detected:
%PY% --version
echo.

REM --- 2. Install Python packages (no fastmcp needed) ---
echo [2/5] Installing Python packages: playwright, pillow, python-pptx ...
%PY% -m pip install --upgrade pip
%PY% -m pip install playwright pillow python-pptx
if errorlevel 1 (
  echo [ERROR] pip install failed. Check your network / proxy and re-run.
  pause
  exit /b 1
)
echo.

REM --- 3. Download Chromium browser for Playwright (the only big download) ---
echo [3/5] Downloading Chromium browser for Playwright ^(~150 MB, one time^) ...
%PY% -m playwright install chromium
if errorlevel 1 (
  echo [WARN] Chromium download failed. You can re-run later with:  %PY% -m playwright install chromium
)
echo.

REM --- 4. Deploy files to Documents\Geotech ---
set "DEST=%USERPROFILE%\Documents\Geotech"
echo [4/5] Installing files to: %DEST%
if not exist "%DEST%" mkdir "%DEST%"
xcopy /E /I /Y "%~dp0bin" "%DEST%\bin" >nul
xcopy /E /I /Y "%~dp0.claude" "%DEST%\.claude" >nul
xcopy /E /I /Y "%~dp0examples" "%DEST%\examples" >nul
copy /Y "%~dp0geotech_input.txt"  "%DEST%\" >nul
copy /Y "%~dp0geotech_manual.html" "%DEST%\" >nul
copy /Y "%~dp0README.txt"          "%DEST%\" >nul
if not exist "%DEST%\output" mkdir "%DEST%\output"
echo.

REM --- 5. Self-test (import core + check deps) ---
echo [5/5] Self-test ...
%PY% -c "import sys; sys.path.insert(0, r'%DEST%\bin'); import os; os.environ['GEOTECH_OUTPUT_DIR']=r'%DEST%\output'; import geotech_core, PIL, pptx, playwright; print('   core + deps OK')"
if errorlevel 1 (
  echo [WARN] Self-test failed. See messages above.
) else (
  echo.
  echo ============================================
  echo    Install complete.
  echo ============================================
)
echo.
echo Next steps:
echo   1. Open Claude Code with this folder as the working directory:
echo        %DEST%
echo   2. In Claude Code type:   /geotech
echo   3. Fill in the input form ^(address / radius / holes / slides^) and it runs end to end.
echo.
echo Manual ^(open in a browser^):  %DEST%\geotech_manual.html
echo.
pause
endlocal
