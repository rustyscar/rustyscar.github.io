@echo off
chcp 950 >nul 2>nul
setlocal enabledelayedexpansion
title Geotech_BH v1.01 - Installer
cd /d "%~dp0"

REM ===== Python version to auto-install if missing =====
set "PYVER=3.12.8"
set "PYURL=https://www.python.org/ftp/python/%PYVER%/python-%PYVER%-amd64.exe"
set "PYDIR=Python%PYVER:~0,1%%PYVER:~2,2%"

echo ============================================
echo    Geotech_BH v1.01 - Installer
echo    (one-time setup; Chinese guide: usage .txt)
echo ============================================
echo.

REM === 1. Detect Python (>=3.10) ===
echo [1/4] Detecting Python ...
set "PY="
call :detectpy
if defined PY (
  echo      Found usable Python:
  %PY% --version
  goto deps
)

echo      No Python 3.10+ found. Downloading official installer (~25MB) ...
set "PYINST=%TEMP%\python-%PYVER%-amd64.exe"
powershell -NoProfile -Command "try{[Net.ServicePointManager]::SecurityProtocol=[Net.SecurityProtocolType]::Tls12;Invoke-WebRequest -Uri '%PYURL%' -OutFile '!PYINST!'}catch{exit 1}"
if errorlevel 1 (
  echo [ERROR] Python download failed. Check network and retry, or install Python 3.12 from python.org
  pause
  exit /b 1
)
echo      Installing Python %PYVER% silently (adds to PATH) ...
"!PYINST!" /quiet InstallAllUsers=0 PrependPath=1 Include_pip=1 Include_test=0
call :detectpy
if not defined PY (
  if exist "%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe""
)
if not defined PY (
  echo [ERROR] Python still not found after install. Please REBOOT and run this installer once more.
  pause
  exit /b 1
)
echo      Python installed:
%PY% --version

:deps
echo.
REM === 2. Install Python packages ===
echo [2/4] Installing packages: playwright, pillow, python-pptx ...
%PY% -m pip install --upgrade pip
%PY% -m pip install playwright pillow python-pptx
if errorlevel 1 (
  echo [ERROR] pip install failed. Check network / proxy and retry.
  pause
  exit /b 1
)
echo.

REM === 3. Ensure Chromium is present (uses default cache; skips if already installed) ===
echo [3/4] Checking Chromium browser (downloads ~150MB ONLY if this PC lacks it) ...
%PY% -m playwright install chromium
if errorlevel 1 (
  echo [WARN] Chromium download failed. Re-run this installer later. Plotting still works.
)
echo.

REM === 4. Self-test ===
echo [4/4] Self-test ...
%PY% -c "import PIL, playwright; print('      dependencies OK')"
echo.
echo ============================================
echo    Install complete.
echo      To run: double-click the fetch-and-plot batch
echo    (See the Chinese usage .txt in this folder)
echo ============================================
echo.
pause
exit /b 0

REM ---- detect a usable Python (>=3.10), set PY ----
:detectpy
set "PY="
where py >nul 2>nul && ( py -3 -c "import sys;sys.exit(0 if sys.version_info[:2]>=(3,10) else 1)" 2>nul && set "PY=py -3" )
if defined PY exit /b 0
where python >nul 2>nul && ( python -c "import sys;sys.exit(0 if sys.version_info[:2]>=(3,10) else 1)" 2>nul && set "PY=python" )
if defined PY exit /b 0
if exist "%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe""
exit /b 0
