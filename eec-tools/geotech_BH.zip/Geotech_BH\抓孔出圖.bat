@echo off
chcp 950 >nul 2>nul
setlocal
cd /d "%~dp0"
set "OUT=%~dp0output"
set "PYDIR=Python312"
title Geotech_BH - Fetch and Plot

REM === Detect Python ===
set "PY="
where py >nul 2>nul && set "PY=py -3"
if not defined PY ( where python >nul 2>nul && set "PY=python" )
if not defined PY if exist "%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe" set "PY="%LOCALAPPDATA%\Programs\Python\%PYDIR%\python.exe""
if not defined PY (
  echo [No Python] Please run the installer batch first.
  pause
  exit /b 1
)

echo ============================================
echo    Geotech - fetch boreholes and make plots
echo ============================================
echo.
echo === Fetching: you will be prompted for the address (Python reads it; ~20-40s) ===
%PY% "%~dp0bin\geotech_cli.py" fetch --out "%OUT%"
if errorlevel 1 (
  echo.
  echo [Fetch failed or cancelled] No boreholes, address not located, or network issue.
  pause
  exit /b 1
)

echo.
echo === Plotting (azimuth/distance table + position map PNG) ===
%PY% "%~dp0bin\geotech_plot.py" --latest "%OUT%" --svg
if errorlevel 1 (
  echo [Plot failed]
  pause
  exit /b 1
)

echo.
echo [Done] Opening result folder ...
start "" "%OUT%"
echo Column charts: charts\ in each hole folder. Position map: position_map.png + points_table.* in the same folder.
pause
